import React, { useState } from 'react';
import { GAMES_DATA } from '../constants';
import { Heart, Search, Star, Zap, Users } from 'lucide-react';
import { Game } from '../types';

interface DiscoveryViewProps {
  onAddToWishlist: (gameId: string) => void;
  wishlist: string[];
}

export const DiscoveryView: React.FC<DiscoveryViewProps> = ({ onAddToWishlist, wishlist }) => {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const categories = [
    { id: 'all', label: '全部' },
    { id: 'party', label: '派对精选' },
    { id: 'coop', label: '双人合作' },
    { id: 'family', label: '家庭同乐' },
    { id: 'ranking', label: '热门排行' }
  ];

  const filteredGames = activeCategory === 'all' 
    ? GAMES_DATA 
    : GAMES_DATA.filter(g => g.category === activeCategory);

  return (
    <div className="flex flex-col h-full bg-slate-900 text-white overflow-hidden">
      {/* Top Bar */}
      <div className="pt-12 px-6 pb-4 flex items-center justify-between bg-slate-900 z-10">
        <h2 className="text-2xl font-black italic tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-500">
          DISCOVER
        </h2>
        <button className="p-2 bg-slate-800 rounded-full text-slate-400 hover:text-white transition-colors">
          <Search className="w-5 h-5" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto pb-24 no-scrollbar">
        {/* Carousel / Featured */}
        <div className="mt-2 mb-8 px-6">
            <div className="w-full h-48 rounded-2xl relative overflow-hidden bg-gradient-to-br from-indigo-500 to-purple-600 shadow-2xl shadow-purple-500/20">
                <img src="https://picsum.photos/seed/featured/600/300" alt="Featured" className="absolute inset-0 w-full h-full object-cover mix-blend-overlay opacity-60" />
                <div className="absolute bottom-0 left-0 p-6 w-full bg-gradient-to-t from-slate-900 to-transparent">
                    <span className="inline-block px-2 py-1 bg-yellow-400 text-black text-xs font-bold rounded mb-2">本周新游</span>
                    <h3 className="text-xl font-bold">超级马力欧派对：空前盛会</h3>
                    <p className="text-slate-300 text-xs mt-1">全新的岛屿，全新的玩法！</p>
                </div>
            </div>
        </div>

        {/* Category Pills */}
        <div className="flex gap-3 px-6 overflow-x-auto no-scrollbar mb-6 pb-2">
            {categories.map(cat => (
                <button
                    key={cat.id}
                    onClick={() => setActiveCategory(cat.id)}
                    className={`whitespace-nowrap px-4 py-2 rounded-full text-sm font-bold transition-all ${
                        activeCategory === cat.id 
                        ? 'bg-white text-slate-900 shadow-[0_0_15px_rgba(255,255,255,0.3)] scale-105' 
                        : 'bg-slate-800 text-slate-400 border border-slate-700'
                    }`}
                >
                    {cat.label}
                </button>
            ))}
        </div>

        {/* Game Grid */}
        <div className="grid grid-cols-2 gap-4 px-6">
            {filteredGames.map((game) => {
                const isWished = wishlist.includes(game.id);
                return (
                    <div key={game.id} className="group relative bg-slate-800 rounded-2xl overflow-hidden border border-slate-700 hover:border-cyan-500/50 transition-all">
                        {/* Image */}
                        <div className="aspect-[3/4] relative">
                            <img src={game.coverUrl} alt={game.title} className="w-full h-full object-cover transition-transform group-hover:scale-105" />
                            <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent opacity-80" />
                            
                            {/* Tags on Image */}
                            <div className="absolute bottom-2 left-2 flex flex-wrap gap-1">
                                {game.tags.slice(0, 1).map(tag => (
                                    <span key={tag} className="px-2 py-0.5 bg-slate-900/80 backdrop-blur text-xs text-cyan-300 rounded border border-slate-700">
                                        {tag}
                                    </span>
                                ))}
                            </div>
                            
                            {/* Wishlist Button */}
                            <button 
                                onClick={(e) => {
                                    e.stopPropagation();
                                    onAddToWishlist(game.id);
                                }}
                                className="absolute top-2 right-2 p-2 bg-slate-900/50 backdrop-blur rounded-full hover:bg-red-500/20 transition-colors"
                            >
                                <Heart 
                                    className={`w-5 h-5 transition-all ${isWished ? 'fill-red-500 text-red-500 scale-110' : 'text-white'}`} 
                                />
                            </button>
                        </div>

                        {/* Info */}
                        <div className="p-3">
                            <h3 className="font-bold text-sm text-gray-100 truncate">{game.title}</h3>
                            <div className="flex items-center gap-1 mt-1 text-xs text-gray-500">
                                {/* Fixed: Added Users to imports above to support this usage */}
                                <Users className="w-3 h-3" />
                                <span>{game.players} 人</span>
                            </div>
                        </div>
                    </div>
                )
            })}
        </div>
      </div>
    </div>
  );
};