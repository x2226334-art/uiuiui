import React, { useState } from 'react';
import { X, Camera, MessageSquare, AlertCircle, Coffee, Thermometer } from 'lucide-react';
import { ServiceRequest } from '../types';

interface ServiceModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ServiceModal: React.FC<ServiceModalProps> = ({ isOpen, onClose }) => {
  const [step, setStep] = useState<1 | 2>(1);
  const [request, setRequest] = useState<ServiceRequest>({ type: 'other', details: '' });
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = () => {
    setIsSubmitting(true);
    setTimeout(() => {
        setIsSubmitting(false);
        alert("服务呼叫已提交，店员正在赶来！");
        onClose();
        setStep(1);
        setRequest({ type: 'other', details: '' });
    }, 1500);
  };

  const quickOptions = [
    { id: 'equipment', label: '设备故障', icon: <AlertCircle className="w-6 h-6 text-red-500"/>, color: 'bg-red-50' },
    { id: 'drink', label: '点单/加水', icon: <Coffee className="w-6 h-6 text-orange-500"/>, color: 'bg-orange-50' },
    { id: 'environment', label: '调节温度', icon: <Thermometer className="w-6 h-6 text-blue-500"/>, color: 'bg-blue-50' },
    { id: 'other', label: '其他帮助', icon: <MessageSquare className="w-6 h-6 text-purple-500"/>, color: 'bg-purple-50' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={onClose}></div>

      {/* Modal */}
      <div className="bg-white rounded-[2rem] w-full max-w-sm overflow-hidden shadow-2xl relative animate-bounce-in z-10">
        <div className="p-6 bg-gradient-to-r from-blue-500 to-cyan-500 text-white flex justify-between items-center">
            <div>
                <h3 className="text-xl font-bold">呼叫服务</h3>
                <p className="text-blue-100 text-xs">店员将在3分钟内响应</p>
            </div>
            <button onClick={onClose} className="p-2 bg-white/20 rounded-full hover:bg-white/30 transition-colors">
                <X className="w-5 h-5" />
            </button>
        </div>

        <div className="p-6">
            {step === 1 ? (
                <div className="grid grid-cols-2 gap-4">
                    {quickOptions.map(opt => (
                        <button
                            key={opt.id}
                            onClick={() => {
                                setRequest({ ...request, type: opt.id as any });
                                setStep(2);
                            }}
                            className={`${opt.color} p-4 rounded-2xl flex flex-col items-center justify-center gap-3 hover:scale-105 transition-transform border border-transparent hover:border-black/5`}
                        >
                            <div className="bg-white p-3 rounded-full shadow-sm">
                                {opt.icon}
                            </div>
                            <span className="font-bold text-slate-700 text-sm">{opt.label}</span>
                        </button>
                    ))}
                </div>
            ) : (
                <div className="space-y-4">
                     <div>
                        <label className="block text-sm font-bold text-gray-700 mb-2">详情描述</label>
                        <textarea 
                            className="w-full bg-gray-50 rounded-xl p-3 text-sm focus:ring-2 focus:ring-blue-500 outline-none resize-none h-24"
                            placeholder="请简单描述您的需求..."
                            value={request.details}
                            onChange={(e) => setRequest({...request, details: e.target.value})}
                        ></textarea>
                     </div>

                     <div className="flex items-center gap-3">
                         <label className="flex-1 h-12 bg-gray-50 border border-dashed border-gray-300 rounded-xl flex items-center justify-center gap-2 cursor-pointer hover:bg-gray-100 transition-colors text-gray-500 text-sm">
                             <Camera className="w-4 h-4" />
                             <span>拍照上传 (可选)</span>
                             <input type="file" className="hidden" accept="image/*" />
                         </label>
                     </div>

                     <button 
                        onClick={handleSubmit}
                        disabled={isSubmitting}
                        className="w-full bg-blue-600 text-white font-bold py-3 rounded-xl shadow-lg shadow-blue-500/30 active:scale-95 transition-transform flex justify-center"
                     >
                         {isSubmitting ? '提交中...' : '立即提交'}
                     </button>
                     <p className="text-center text-xs text-gray-400 mt-2">点击提交即表示同意服务条款</p>
                </div>
            )}
        </div>
      </div>
    </div>
  );
};