import React, { useState, useEffect } from 'react';
import { BookingState, Room } from '../types';
import { ROOMS_DATA, TIME_SLOTS, GAMES_DATA } from '../constants';
import { Check, ChevronLeft, Clock, Info, Tv, Wifi, Volume2, Gamepad2 } from 'lucide-react';

interface BookingWizardProps {
  onCancel: () => void;
  wishlist: string[];
}

export const BookingWizard: React.FC<BookingWizardProps> = ({ onCancel, wishlist }) => {
  const [state, setState] = useState<BookingState>({
    step: 1,
    selectedRoomId: null,
    selectedDate: new Date(),
    selectedTimeSlots: [],
    selectedGames: []
  });

  // Calculate costs
  const selectedRoom = ROOMS_DATA.find(r => r.id === state.selectedRoomId);
  const totalCost = selectedRoom ? selectedRoom.pricePerHour * state.selectedTimeSlots.length : 0;

  const handleNext = () => {
    setState(prev => ({ ...prev, step: (prev.step + 1) as any }));
  };

  const handleBack = () => {
    if (state.step === 1) onCancel();
    else setState(prev => ({ ...prev, step: (prev.step - 1) as any }));
  };

  const toggleTimeSlot = (hour: number) => {
    setState(prev => {
      const exists = prev.selectedTimeSlots.includes(hour);
      if (exists) return { ...prev, selectedTimeSlots: prev.selectedTimeSlots.filter(h => h !== hour) };
      return { ...prev, selectedTimeSlots: [...prev.selectedTimeSlots, hour].sort((a,b) => a-b) };
    });
  };

  // Step 1: Room Selection
  const renderRoomSelection = () => (
    <div className="space-y-4 px-4 pb-24">
      <h2 className="text-xl font-bold text-slate-800">选择房型</h2>
      {ROOMS_DATA.map(room => (
        <div 
          key={room.id}
          onClick={() => setState(s => ({ ...s, selectedRoomId: room.id }))}
          className={`bg-white rounded-2xl overflow-hidden shadow-sm border-2 transition-all cursor-pointer ${
            state.selectedRoomId === room.id ? 'border-red-500 ring-4 ring-red-500/10' : 'border-transparent'
          }`}
        >
          <div className="h-40 bg-gray-200 relative">
            <img src={room.imageUrl} className="w-full h-full object-cover" alt={room.name} />
            <div className="absolute bottom-2 right-2 bg-black/70 text-white text-xs px-2 py-1 rounded-md">
                ¥{room.pricePerHour}/小时
            </div>
          </div>
          <div className="p-4">
            <div className="flex justify-between items-center mb-2">
                <h3 className="font-bold text-lg">{room.name}</h3>
                <div className={`w-6 h-6 rounded-full border flex items-center justify-center ${
                    state.selectedRoomId === room.id ? 'bg-red-500 border-red-500' : 'border-gray-300'
                }`}>
                    {state.selectedRoomId === room.id && <Check className="w-4 h-4 text-white" />}
                </div>
            </div>
            
            <div className="flex gap-3 text-gray-500 text-sm">
                {room.features.slice(0,3).map((f, i) => (
                    <span key={i} className="flex items-center gap-1 bg-gray-100 px-2 py-1 rounded">
                        {i === 0 ? <Tv className="w-3 h-3"/> : i === 1 ? <Volume2 className="w-3 h-3"/> : <Wifi className="w-3 h-3"/>}
                        {f}
                    </span>
                ))}
            </div>
          </div>
        </div>
      ))}
    </div>
  );

  // Step 2: Time Selection
  const renderTimeSelection = () => (
    <div className="space-y-6 px-4 pb-24">
       <h2 className="text-xl font-bold text-slate-800">选择时段 ({state.selectedDate.toLocaleDateString()})</h2>
       
       <div className="grid grid-cols-4 gap-3">
         {TIME_SLOTS.map(hour => {
           // Mock unavailable slots
           const isTaken = hour === 14 || hour === 15; 
           const isSelected = state.selectedTimeSlots.includes(hour);
           
           return (
             <button
                key={hour}
                disabled={isTaken}
                onClick={() => toggleTimeSlot(hour)}
                className={`py-3 rounded-xl text-sm font-bold flex flex-col items-center justify-center border-2 transition-all ${
                    isTaken 
                        ? 'bg-gray-100 text-gray-300 border-transparent cursor-not-allowed' 
                        : isSelected 
                            ? 'bg-green-100 border-green-500 text-green-700' 
                            : 'bg-white border-gray-100 text-slate-700 hover:border-green-200'
                }`}
             >
                <span>{hour}:00</span>
                <span className="text-xs font-normal mt-1">
                    {isTaken ? '已满' : isSelected ? '已选' : '可选'}
                </span>
             </button>
           );
         })}
       </div>

       {state.selectedTimeSlots.length > 0 && (
           <div className="bg-slate-900 text-white p-4 rounded-xl flex justify-between items-center">
               <div>
                   <p className="text-xs text-slate-400">预计费用</p>
                   <p className="text-xl font-bold">¥{totalCost}</p>
               </div>
               <div className="text-right">
                   <p className="text-xs text-slate-400">总时长</p>
                   <p className="font-bold">{state.selectedTimeSlots.length} 小时</p>
               </div>
           </div>
       )}
    </div>
  );

  // Step 3: Confirmation
  const renderConfirmation = () => (
    <div className="space-y-6 px-4 pb-32">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
            <h2 className="text-xl font-bold text-slate-800 mb-4 border-b pb-2">订单确认</h2>
            <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                    <span className="text-gray-500">房型</span>
                    <span className="font-bold">{selectedRoom?.name}</span>
                </div>
                <div className="flex justify-between">
                    <span className="text-gray-500">日期</span>
                    <span className="font-bold">{state.selectedDate.toLocaleDateString()}</span>
                </div>
                <div className="flex justify-between">
                    <span className="text-gray-500">时段</span>
                    <span className="font-bold">
                        {state.selectedTimeSlots.length > 0 
                            ? `${Math.min(...state.selectedTimeSlots)}:00 - ${Math.max(...state.selectedTimeSlots) + 1}:00` 
                            : '-'}
                    </span>
                </div>
                <div className="flex justify-between text-lg text-red-500 font-black pt-2 border-t">
                    <span>总计</span>
                    <span>¥{totalCost}</span>
                </div>
            </div>
        </div>

        {/* Wishlist Add-on */}
        <div>
            <h3 className="text-sm font-bold text-gray-500 mb-3 uppercase tracking-wider">心愿单游戏预装</h3>
            {wishlist.length === 0 ? (
                <div className="p-4 bg-gray-50 rounded-xl text-center text-gray-400 text-sm dashed border border-gray-200">
                    暂时没有加入心愿单的游戏
                </div>
            ) : (
                <div className="space-y-2">
                    {GAMES_DATA.filter(g => wishlist.includes(g.id)).map(game => (
                        <div key={game.id} className="flex items-center gap-3 p-2 bg-white rounded-xl border border-gray-100">
                            <img src={game.coverUrl} className="w-10 h-10 rounded-lg object-cover" alt="" />
                            <span className="text-sm font-medium flex-1">{game.title}</span>
                            <Check className="w-5 h-5 text-green-500" />
                        </div>
                    ))}
                </div>
            )}
        </div>
    </div>
  );

  return (
    <div className="h-full flex flex-col bg-gray-50">
      {/* Header */}
      <div className="bg-white p-4 flex items-center gap-4 sticky top-0 z-20 shadow-sm">
        <button onClick={handleBack} className="p-2 hover:bg-gray-100 rounded-full">
            <ChevronLeft className="w-6 h-6" />
        </button>
        <h1 className="text-lg font-bold">
            {state.step === 1 ? '选择房型' : state.step === 2 ? '选择时间' : '确认订单'}
        </h1>
        <div className="ml-auto text-sm text-gray-400 font-mono">
            {state.step}/3
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto pt-6">
        {state.step === 1 && renderRoomSelection()}
        {state.step === 2 && renderTimeSelection()}
        {state.step === 3 && renderConfirmation()}
      </div>

      {/* Bottom Action */}
      <div className="bg-white p-4 border-t sticky bottom-0 safe-area-bottom">
        {state.step === 3 ? (
            <div className="space-y-3">
                <label className="flex items-center gap-2 text-xs text-gray-500">
                    <input type="checkbox" className="rounded text-red-500 focus:ring-red-500" defaultChecked />
                    我已阅读并同意《用户入场协议》
                </label>
                <button 
                    onClick={() => alert("支付功能模拟成功！")}
                    className="w-full bg-red-500 text-white font-bold py-4 rounded-xl shadow-lg shadow-red-500/30 active:scale-95 transition-transform"
                >
                    确认支付 ¥{totalCost}
                </button>
            </div>
        ) : (
            <button 
                onClick={handleNext}
                disabled={state.step === 1 && !state.selectedRoomId || state.step === 2 && state.selectedTimeSlots.length === 0}
                className="w-full bg-slate-900 text-white font-bold py-4 rounded-xl disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
            >
                下一步
            </button>
        )}
      </div>
    </div>
  );
};