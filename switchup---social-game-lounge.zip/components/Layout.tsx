import React from 'react';
import { Home, Compass, Calendar, User, BellRing } from 'lucide-react';
import { ViewState } from '../types';

interface LayoutProps {
  currentView: ViewState;
  onChangeView: (view: ViewState) => void;
  children: React.ReactNode;
  onOpenService: () => void;
  isBookingMode: boolean; // Hide nav during wizard
}

export const Layout: React.FC<LayoutProps> = ({ 
  currentView, 
  onChangeView, 
  children, 
  onOpenService,
  isBookingMode 
}) => {
  
  if (isBookingMode) {
      return <div className="h-full w-full bg-white">{children}</div>;
  }

  const navItems = [
    { id: 'home', label: '首页', icon: Home },
    { id: 'discovery', label: '发现', icon: Compass },
    { id: 'booking', label: '预约', icon: Calendar },
    { id: 'profile', label: '我的', icon: User },
  ];

  return (
    <div className="flex flex-col h-full relative">
      <main className="flex-1 overflow-hidden relative">
        {children}
        
        {/* Floating Service Button */}
        <button 
            onClick={onOpenService}
            className="absolute bottom-6 right-6 z-30 w-14 h-14 bg-blue-600 rounded-full shadow-lg shadow-blue-600/40 flex items-center justify-center text-white active:scale-90 transition-transform animate-pulse-slow"
        >
            <BellRing className="w-6 h-6" />
        </button>
      </main>

      {/* Bottom Navigation */}
      <nav className="h-20 bg-white border-t border-gray-100 flex items-center justify-around px-2 pb-2 z-40 relative">
        {navItems.map((item) => {
            const isActive = currentView === item.id;
            const Icon = item.icon;
            return (
                <button
                    key={item.id}
                    onClick={() => onChangeView(item.id as ViewState)}
                    className="flex-1 flex flex-col items-center justify-center gap-1 active:scale-95 transition-transform"
                >
                    <div className={`p-1.5 rounded-xl transition-colors ${isActive ? 'bg-red-50' : 'bg-transparent'}`}>
                        <Icon 
                            className={`w-6 h-6 transition-colors ${isActive ? 'text-red-500 fill-current' : 'text-gray-400'}`} 
                            strokeWidth={isActive ? 2.5 : 2}
                        />
                    </div>
                    <span className={`text-[10px] font-bold ${isActive ? 'text-red-500' : 'text-gray-400'}`}>
                        {item.label}
                    </span>
                </button>
            )
        })}
      </nav>
    </div>
  );
};