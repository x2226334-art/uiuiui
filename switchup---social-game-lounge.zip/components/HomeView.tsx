import React from 'react';
import { Calendar, Gamepad2, Heart, Users, ArrowRight } from 'lucide-react';
import { ViewState } from '../types';

interface HomeViewProps {
  onChangeView: (view: ViewState) => void;
}

export const HomeView: React.FC<HomeViewProps> = ({ onChangeView }) => {
  return (
    <div className="flex flex-col h-full bg-white overflow-y-auto pb-24">
      {/* Header / Hero */}
      <div className="relative bg-gradient-to-r from-red-500 to-rose-600 text-white rounded-b-[2.5rem] p-6 pt-12 shadow-lg z-10">
        <div className="flex justify-between items-start mb-6">
          <div>
            <h1 className="text-3xl font-black tracking-tight mb-1">Switch Up!</h1>
            <p className="text-red-100 text-sm font-medium">Ready to play?</p>
          </div>
          <div className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center border border-white/30">
            <span className="text-lg">🎮</span>
          </div>
        </div>

        <button 
          onClick={() => onChangeView('booking')}
          className="w-full bg-white text-red-600 font-bold text-lg py-4 px-6 rounded-2xl shadow-xl hover:bg-gray-50 active:scale-95 transition-all flex items-center justify-between group"
        >
          <span>立即预约</span>
          <ArrowRight className="w-6 h-6 group-hover:translate-x-1 transition-transform" />
        </button>
      </div>

      {/* Scenario Cards */}
      <div className="px-6 mt-8 space-y-6">
        <h2 className="text-xl font-bold text-slate-800 mb-4">场景推荐</h2>
        
        {/* Friends */}
        <div 
          onClick={() => onChangeView('booking')}
          className="relative h-40 bg-indigo-100 rounded-3xl overflow-hidden cursor-pointer active:scale-95 transition-transform shadow-sm"
        >
          <img src="https://picsum.photos/seed/friends/400/200" alt="Friends" className="absolute inset-0 w-full h-full object-cover opacity-80 mix-blend-overlay" />
          <div className="absolute inset-0 bg-gradient-to-r from-indigo-600/90 to-transparent p-6 flex flex-col justify-center">
            <div className="bg-white/20 w-10 h-10 rounded-xl flex items-center justify-center backdrop-blur-sm mb-3">
              <Gamepad2 className="text-white w-6 h-6" />
            </div>
            <h3 className="text-2xl font-bold text-white">朋友聚会</h3>
            <p className="text-indigo-100 text-sm">4人同屏，友情（破坏）赛</p>
          </div>
        </div>

        {/* Couples */}
        <div 
           onClick={() => onChangeView('booking')}
           className="relative h-40 bg-pink-100 rounded-3xl overflow-hidden cursor-pointer active:scale-95 transition-transform shadow-sm"
        >
          <img src="https://picsum.photos/seed/date/400/200" alt="Couple" className="absolute inset-0 w-full h-full object-cover opacity-80 mix-blend-overlay" />
          <div className="absolute inset-0 bg-gradient-to-r from-rose-500/90 to-transparent p-6 flex flex-col justify-center">
            <div className="bg-white/20 w-10 h-10 rounded-xl flex items-center justify-center backdrop-blur-sm mb-3">
              <Heart className="text-white w-6 h-6" />
            </div>
            <h3 className="text-2xl font-bold text-white">情侣约会</h3>
            <p className="text-rose-100 text-sm">双人包间，甜蜜协作</p>
          </div>
        </div>

        {/* Family */}
        <div 
           onClick={() => onChangeView('booking')}
           className="relative h-40 bg-orange-100 rounded-3xl overflow-hidden cursor-pointer active:scale-95 transition-transform shadow-sm"
        >
          <img src="https://picsum.photos/seed/family/400/200" alt="Family" className="absolute inset-0 w-full h-full object-cover opacity-80 mix-blend-overlay" />
          <div className="absolute inset-0 bg-gradient-to-r from-orange-500/90 to-transparent p-6 flex flex-col justify-center">
            <div className="bg-white/20 w-10 h-10 rounded-xl flex items-center justify-center backdrop-blur-sm mb-3">
              <Users className="text-white w-6 h-6" />
            </div>
            <h3 className="text-2xl font-bold text-white">亲子同乐</h3>
            <p className="text-orange-100 text-sm">全家总动员，欢乐周末</p>
          </div>
        </div>
      </div>
    </div>
  );
};