export type ViewState = 'home' | 'discovery' | 'booking' | 'profile';

export interface Game {
  id: string;
  title: string;
  coverUrl: string;
  tags: string[];
  category: 'party' | 'coop' | 'family' | 'ranking';
  players: string;
  isNew?: boolean;
}

export interface Room {
  id: string;
  name: string;
  type: 'open' | 'booth' | 'private' | 'family';
  imageUrl: string;
  features: string[];
  pricePerHour: number;
  capacity: string;
}

export interface BookingState {
  step: 1 | 2 | 3;
  selectedRoomId: string | null;
  selectedDate: Date;
  selectedTimeSlots: number[]; // Hours 0-23
  selectedGames: string[]; // Game IDs
}

export interface ServiceRequest {
  type: 'equipment' | 'drink' | 'environment' | 'other';
  details: string;
  image?: File | null;
}
