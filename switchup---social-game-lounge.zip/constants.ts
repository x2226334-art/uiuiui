import { Game, Room } from './types';
import { Wifi, Volume2, Sofa, Users, Tv, Gamepad2 } from 'lucide-react';

export const GAMES_DATA: Game[] = [
  {
    id: 'g1',
    title: 'Super Party Stars',
    coverUrl: 'https://picsum.photos/seed/mario/300/400',
    tags: ['4人同屏', '简单有趣', '友情破坏'],
    category: 'party',
    players: '1-4',
    isNew: true
  },
  {
    id: 'g2',
    title: 'Kart Racing 8',
    coverUrl: 'https://picsum.photos/seed/kart/300/400',
    tags: ['竞速', '道具战'],
    category: 'ranking',
    players: '1-4'
  },
  {
    id: 'g3',
    title: 'Kitchen Chaos 2',
    coverUrl: 'https://picsum.photos/seed/cook/300/400',
    tags: ['双人合作', '默契考验'],
    category: 'coop',
    players: '1-4'
  },
  {
    id: 'g4',
    title: 'Dance Rhythm',
    coverUrl: 'https://picsum.photos/seed/dance/300/400',
    tags: ['体感', '运动'],
    category: 'party',
    players: '1-6'
  },
  {
    id: 'g5',
    title: 'Zelda Adventure',
    coverUrl: 'https://picsum.photos/seed/zelda/300/400',
    tags: ['单人剧情', '开放世界'],
    category: 'ranking',
    players: '1'
  },
  {
    id: 'g6',
    title: 'Sports Switch',
    coverUrl: 'https://picsum.photos/seed/sport/300/400',
    tags: ['家庭同乐', '轻松'],
    category: 'family',
    players: '1-4'
  }
];

export const ROOMS_DATA: Room[] = [
  {
    id: 'r1',
    name: '开放式联机区',
    type: 'open',
    imageUrl: 'https://picsum.photos/seed/room1/600/400',
    features: ['高刷屏', '懒人沙发', '开放社交'],
    pricePerHour: 20,
    capacity: '2人'
  },
  {
    id: 'r2',
    name: '半封闭卡座',
    type: 'booth',
    imageUrl: 'https://picsum.photos/seed/room2/600/400',
    features: ['相对私密', '大屏电视', '餐饮桌'],
    pricePerHour: 35,
    capacity: '2-4人'
  },
  {
    id: 'r3',
    name: '静谧双人包间',
    type: 'private',
    imageUrl: 'https://picsum.photos/seed/room3/600/400',
    features: ['完全隔音', '情侣氛围', '投影仪'],
    pricePerHour: 50,
    capacity: '2人'
  },
  {
    id: 'r4',
    name: '亲子主题房',
    type: 'family',
    imageUrl: 'https://picsum.photos/seed/room4/600/400',
    features: ['儿童护眼', '地毯', '玩具角'],
    pricePerHour: 60,
    capacity: '3-5人'
  }
];

export const TIME_SLOTS = Array.from({ length: 14 }, (_, i) => i + 10); // 10:00 to 23:00
