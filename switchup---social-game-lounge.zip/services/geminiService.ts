import { GoogleGenAI } from "@google/genai";

// Initialize the API client
// Note: In a real production app, ensure your API key is secure.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || 'demo-key' });

export const getSmartResponse = async (userMessage: string): Promise<string> => {
  try {
    if (!process.env.API_KEY) {
      // Return a simulation if no key is present for the demo UI
      return "这是模拟回复：我们的服务员马上就到！如果您有其他需求，请继续点击选项。";
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `You are a helpful customer service assistant for a Switch Game Lounge. 
      The user is asking: "${userMessage}". 
      Keep the response short, friendly, and under 50 words.`,
    });
    
    return response.text || "收到您的请求，我们会尽快处理。";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "网络连接异常，但我们要尽快通知店员处理您的请求。";
  }
};