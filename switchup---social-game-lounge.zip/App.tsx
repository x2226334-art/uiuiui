import React, { useState } from 'react';
import { Layout } from './components/Layout';
import { HomeView } from './components/HomeView';
import { DiscoveryView } from './components/DiscoveryView';
import { BookingWizard } from './components/BookingWizard';
import { ServiceModal } from './components/ServiceModal';
import { ViewState } from './types';

function App() {
  const [currentView, setCurrentView] = useState<ViewState>('home');
  const [wishlist, setWishlist] = useState<string[]>([]);
  const [isServiceOpen, setIsServiceOpen] = useState(false);

  // Discovery Wishlist Logic
  const handleAddToWishlist = (gameId: string) => {
    setWishlist(prev => {
        if (prev.includes(gameId)) return prev.filter(id => id !== gameId);
        return [...prev, gameId];
    });
  };

  const renderContent = () => {
    switch (currentView) {
      case 'home':
        return <HomeView onChangeView={setCurrentView} />;
      case 'discovery':
        return <DiscoveryView onAddToWishlist={handleAddToWishlist} wishlist={wishlist} />;
      case 'booking':
        // If simply navigating to booking tab, show wizard step 1
        return <BookingWizard onCancel={() => setCurrentView('home')} wishlist={wishlist} />;
      case 'profile':
        return (
            <div className="flex items-center justify-center h-full text-gray-400 bg-white">
                <p>Profile Page Placeholder</p>
            </div>
        );
      default:
        return <HomeView onChangeView={setCurrentView} />;
    }
  };

  return (
    <>
        <Layout 
            currentView={currentView} 
            onChangeView={setCurrentView}
            onOpenService={() => setIsServiceOpen(true)}
            isBookingMode={currentView === 'booking'} // Hide nav when in wizard
        >
            {renderContent()}
        </Layout>

        <ServiceModal 
            isOpen={isServiceOpen} 
            onClose={() => setIsServiceOpen(false)} 
        />
    </>
  );
}

export default App;